#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
[[ $(hostname -s) == gsbuatappl05 && $EUID == 0 ]] || { echo 'STOP: wrong host or not root'; exit 1; }
unit=rke2-agent.service
backup=/apps/rke2-recovery.VAR0jdkg
rel=io.containerd.metadata.v1.bolt/meta.db
live=/apps/rke2-data/agent/containerd/$rel
cand=/apps/rke2-rehearsal.OzmYeU9S/root/$rel
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
ver="$here/verifydelta-amd64"
[[ $(sha256sum "$ver" | cut -d' ' -f1) == d0ddc10d2ba0fd2e4301e5ebd84f631c36971fe677b286eecf6caffb0450117b ]]
quiet(){
 test "$(systemctl show "$unit" -p MainPID --value)" = 0
 test "$(systemctl show "$unit" -p Restart --value)" = no
 test -z "$(systemctl show "$unit" -p ExecStopPost --value)"
 local listeners; listeners=$(ss -xlH)
 if grep -Fq '/run/k3s/containerd/containerd.sock' <<< "$listeners"; then echo 'STOP: RKE2 socket in use'; exit 1; fi
}
quiet
(cd "$backup" && sha256sum -c SHA256SUMS)
[[ -f $live && ! -L $live && -f $cand && ! -L $cand ]]
exec 9<"$live"; flock -xn 9 || { echo 'STOP: live database locked'; exit 1; }
cmp -- "$live" "$backup/meta.db"
staged=$(mktemp "$(dirname "$live")/.verified-repair.XXXXXXXX")
trap 'rm -f -- "$staged"' EXIT
cp --preserve=all -- "$live" "$staged"
cat -- "$cand" > "$staged"
[[ $(stat -c '%u:%g:%a:%C' "$live") == "$(stat -c '%u:%g:%a:%C' "$staged")" ]]
"$ver" "$backup/meta.db" "$staged"
quiet
cmp -- "$live" "$backup/meta.db"
sync -f "$staged"
mv -T -- "$staged" "$live"
sync -f "$live"
exec 9<&-
echo 'Verified metadata installed. Requesting one RKE2 start; auto-restart remains disabled.'
systemctl start --no-block "$unit"
